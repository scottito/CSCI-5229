// Scott Hardman
// The Swordfish II from Cowboy Bebop
void swordfish2(double x, double y,  double z, double dx, double dy, double dz, double ux, double uy, double uz, double s, int engine_on, int thruster_shader, int shader);