// Scott Hardman
// Draw a satellite
void satellite(double x, double y,  double z,
                      double dx, double dy, double dz,
                      double ux, double uy, double uz,
                      double s, unsigned int solar_panel_texture);